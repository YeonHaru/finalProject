package com.error404.geulbut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeulbutApplicationTests {

	@Test
	void contextLoads() {
	}

}
