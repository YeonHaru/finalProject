package com.error404.geulbut.jpa.notice.dto;

public class NoticeDto {
}
