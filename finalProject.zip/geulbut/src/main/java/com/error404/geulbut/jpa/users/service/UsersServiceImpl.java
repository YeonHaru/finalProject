package com.error404.geulbut.jpa.users.service;


public class UsersServiceImpl {
}
