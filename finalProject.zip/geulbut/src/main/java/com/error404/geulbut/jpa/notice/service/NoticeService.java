package com.error404.geulbut.jpa.notice.service;

public class NoticeService {
}
