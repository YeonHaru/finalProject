package com.error404.geulbut.jpa.notice.repository;

public interface NoticeRepository {
}
